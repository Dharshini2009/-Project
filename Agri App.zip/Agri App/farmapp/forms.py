from django import forms
from farmapp.models import Sellproduct
'''
class UserProfileForm(forms.ModelForm):
    class Meta:
        model = UserProfile
        fields = ['name','email','location','phone']
'''
'''
class SellproductForm(forms.ModelForm):
    class Meta:
        model = ProductAvailability
        fields = ['name','product_name', 'location', 'quantity', 'date','phone_number']
 ''' 